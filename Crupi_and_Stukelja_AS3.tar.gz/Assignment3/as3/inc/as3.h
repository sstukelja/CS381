/*
 * As2.h
 *
 *  Created on: Jan 24, 2017
 *      Author: sushil
 *
 *      Used by: Stefan Stukelja and Alex Crupi
 *      For: CS 381 - Assignment 3
 */

#ifndef __As2_h_
#define __As2_h_


#include <engine.h>

class As3 {
private:

public:
  As3();
  ~As3();
};

#endif // #ifndef __As2_h_
