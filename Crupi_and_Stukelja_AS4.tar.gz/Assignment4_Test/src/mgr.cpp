/*
 * mgr.cpp
 *
 *  Created on: Mar 9, 2017
 *      Author: sushil
 *
 *      Used by: Stefan Stukelja and Alex Crupi
 *      For: CS 381 - Assignment 4
 */

#include <mgr.h>

Mgr::Mgr(Engine *eng)
{
	engine = eng;
}
Mgr::~Mgr()
{

}

void Mgr::tick(float dt)
{

}

void Mgr::init()
{

}

void Mgr::loadLevel()
{

}
void Mgr::stop()
{

}
